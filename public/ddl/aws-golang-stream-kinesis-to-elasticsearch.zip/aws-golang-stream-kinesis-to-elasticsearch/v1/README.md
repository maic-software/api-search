<!--
title: TODO
description: This example demonstrates how to stream kinesis information into elasticsearch in a golang runtime 
layout: Doc
framework: v1
platform: AWS
language: Go
authorLink: 'https://github.com/sebito91'
authorName: 'Sebastian Borza'
authorAvatar: 'https://avatars0.githubusercontent.com/u/3159454?v=4&s=140'
-->
