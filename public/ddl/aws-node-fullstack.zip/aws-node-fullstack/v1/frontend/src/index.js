import React from 'react'
import ReactDOM from 'react-dom'
import DemoApp from './DemoApp'
import './index.css'

window.demoapp = {}

ReactDOM.render(<DemoApp />, document.getElementById('root'))
