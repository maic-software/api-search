# AWS FFmepg Layer & a service using it to create GIFs
```
git clone https://github.com/serverless/examples
cd examples/aws-ffmpeg-layer
./build.sh
sls deploy
```

See the blog post about this example for more details:
https://serverless.com/blog/publish-aws-lambda-layers-serverless-framework/
