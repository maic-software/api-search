namespace DotNetServerless.Application.Infrastructure.Configs
{

  public class DynamoDbConfiguration
  {
    public string TableName { get; set; }
  }
}
