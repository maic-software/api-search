/**
 * Created by francois on 2016-08-23.
 */
public class TwilioSmsResponse {
    private String response;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
